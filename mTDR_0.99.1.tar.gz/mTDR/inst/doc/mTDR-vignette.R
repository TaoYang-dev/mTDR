## ----load_packages, include=FALSE----------------------------------------
knitr::opts_knit$set(progress = TRUE, verbose = TRUE)
library(mTDR)
data("chipseq")

## ---- comment = NULL-----------------------------------------------------
dim(chipseq)
head(chipseq) # Each row is a genomic bin of 200 bp, the numbers are the read counts

## ---- comment = NULL-----------------------------------------------------
tdr.out <- est.TDR(chipseq$R1, chipseq$R2, max.it = 200)
# max.it control the maximum iterations for EM algorithm

# print out the estimated quantities
tdr.out$para

# diagnostic plots to monitor the likelihood trace
lik.trc <- tdr.out$likelihood.trace[,3]
plot(1:length(lik.trc), lik.trc, xlab = "Iterations", ylab = "Log likelihood",
     main = "Log likelihood trace")

